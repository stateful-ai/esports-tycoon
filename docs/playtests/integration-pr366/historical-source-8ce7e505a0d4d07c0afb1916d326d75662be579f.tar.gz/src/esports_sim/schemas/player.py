"""Player entity. Attributes are a dict keyed by attribute-registry ids —
adding a new attribute is a config change, not a schema migration.
"""

from __future__ import annotations

from typing import Literal

from pydantic import BaseModel, ConfigDict, Field

from esports_sim.schemas.common import Playstyle, Region, Role


class AgentMastery(BaseModel):
    """Per-agent mastery — a player's third-best Jett is not their main Jett."""

    model_config = ConfigDict(frozen=True, extra="forbid")

    agent_id: str
    mastery: float = Field(ge=0.0, le=100.0)


class MapMastery(BaseModel):
    """Per-map comfort. Teams have map pool depth; so do individuals."""

    model_config = ConfigDict(frozen=True, extra="forbid")

    map_id: str
    mastery: float = Field(ge=0.0, le=100.0)


class LanguageSkill(BaseModel):
    """One language a player speaks, with fluency 0-100. Up to three per
    player. Shared languages drive comms cohesion (relationships layer)."""

    model_config = ConfigDict(frozen=True, extra="forbid")

    lang: str  # ISO-ish code: "en", "pt", "ko", ...
    level: float = Field(ge=0.0, le=100.0)


class PlayerBadge(BaseModel):
    """One badge a player currently holds (manager/badges.py). Rolled at a
    career moment, not guaranteed. `applied` is the REVERSIBLE current-ability
    edge actually applied on earn (subtracted back on decay); `pa_applied` is
    the PERMANENT ceiling revision, kept for the record only (never reverted).
    `last_qualified` is the season the badge was last (re-)earned, which drives
    decay timing."""

    model_config = ConfigDict(extra="forbid")

    id: str
    season: int = 0
    week: int = 0
    applied: dict[str, float] = Field(default_factory=dict)
    pa_applied: float = 0.0
    last_qualified: int = 0


class DevelopmentCurveModel(BaseModel):
    """Hidden career development curve model for serialization."""

    model_config = ConfigDict(extra="forbid")

    archetype: str
    growth_peak_age: int
    growth_width: float
    peak_years: int
    decline_age: int
    realization: float
    volatility: float


class DevelopmentWeek(BaseModel):
    """Measured sources of the latest week's progress, never forecasts."""

    model_config = ConfigDict(extra="forbid")
    season: int
    week: int
    focus: str = "auto"
    intensity: str = "normal"
    maps: int = 0
    rounds: int = 0
    performance_total: float = 0.0
    practice_gains: dict[str, float] = Field(default_factory=dict)
    practice_skills: list[str] = Field(default_factory=list)
    match_gains: dict[str, float] = Field(default_factory=dict)
    scrim_gains: dict[str, float] = Field(default_factory=dict)
    event_gains: dict[str, float] = Field(default_factory=dict)
    factors: list[str] = Field(default_factory=list)
    career_event: str | None = None


class DevelopmentProgress(BaseModel):
    """Persistent career response; hidden headroom is not a scouting view."""

    model_config = ConfigDict(extra="forbid")
    momentum: float = Field(default=0.0, ge=-1.0, le=1.0)
    performance_weeks: int = Field(default=0, ge=0)
    ceiling_shift: float = Field(default=0.0, ge=-6.0, le=6.0)
    event_cooldown: int = Field(default=0, ge=0)
    latest: DevelopmentWeek | None = None


class Player(BaseModel):
    model_config = ConfigDict(extra="forbid")

    dev_seed: int = Field(default=0)
    development_curve: DevelopmentCurveModel | None = Field(default=None)
    development_progress: DevelopmentProgress = Field(default_factory=DevelopmentProgress)


    # Identity
    id: str
    handle: str
    real_name: str = ""
    region: Region = Region.AMERICAS
    age: int = 20
    birth_year: int | None = Field(default=None, description="Calendar year of birth (e.g. 1998). Derived from age as 2021-age for historical packs.")
    # Nationality + spoken languages (up to 3, with fluency). "" / empty on
    # older saves — gen.assign_identity backfills deterministically.
    country: str = ""
    languages: list[LanguageSkill] = Field(default_factory=list)

    # Role / style
    role: Role
    playstyle: Playstyle
    # Experience is assignment-specific: a player can retain some familiarity
    # with an old job, but frequent role/style changes prevent settling in.
    # Empty means an established legacy assignment (100 comfort).
    role_style_comfort: dict[str, float] = Field(default_factory=dict)

    # Attributes: dict keyed by attribute-registry id. Sim code reads by id
    # with a default if a key is missing, so adding attributes is non-breaking.
    attributes: dict[str, float] = Field(default_factory=dict)

    # Per-agent / per-map mastery. MVP uses these in future match-engine tuning;
    # the data is authored now so policies can start reading it immediately.
    agent_pool: list[AgentMastery] = Field(default_factory=list)
    map_pool: list[MapMastery] = Field(default_factory=list)

    # Hidden upside forecast (Potential Ability, 1-99 like attributes). It is
    # not a hard cap: a player's hidden realization curve may fall short, while
    # exceptional mentorship, relationships, and morale can produce a CA above
    # the original number. 0 = unassigned; development.py derives a fallback.
    potential: float = Field(default=0.0, ge=0.0, le=99.0)

    # Per-skill upside forecasts (per-attribute Potential Ability). Sparse: keyed
    # by attribute-registry id, value 0-99. EMPTY by default and on old saves;
    # development.skill_ceiling derives a stable per-skill ceiling from the
    # scalar `potential` plus a blake2 spread when a key is absent, so the
    # default growth math is unchanged. Mentorship and monumental moments
    # WRITE specific entries here to raise the forecast on chosen skills — the
    # only mutable per-skill state a scalar `potential` couldn't carry.
    skill_potential: dict[str, float] = Field(default_factory=dict)

    # Hidden authored career expectation. Historical roster packs can pin the
    # center of a real player's trajectory; new campaigns realize an outcome
    # within this volatility envelope without changing opening attributes.
    career_volatility: float | None = Field(default=None, ge=0.0, le=100.0)
    development_archetype: Literal["flash", "early", "steady", "late"] | None = None
    development_peak_age: int | None = Field(default=None, ge=15, le=40)
    development_peak_years: int | None = Field(default=None, ge=1, le=15)
    development_decline_age: int | None = Field(default=None, ge=20, le=45)
    development_realization: float | None = Field(default=None, ge=0.5, le=1.0)
    development_variance: float | None = Field(default=None, ge=0.65, le=1.35)

    # Badges the player currently holds (manager/badges.py) — rolled at career
    # moments, decaying, with reversible CA edges + permanent ceiling revisions.
    # Empty by default and on old saves.
    badges: list[PlayerBadge] = Field(default_factory=list)

    # Career / contract
    salary: int = 0  # per week
    contract_weeks_left: int = 0
    # Negotiated commercial/protection terms. The player keeps the streaming
    # share; the org receives the remainder. Release fee is owed when the org
    # terminates the deal. A zero buyout means no public clause.
    stream_revenue_share: float = Field(default=0.70, ge=0.0, le=1.0)
    release_fee: int = Field(default=0, ge=0)
    buyout_clause: int = Field(default=0, ge=0)
    no_transfer_clause: bool = False
    roster_role: str = "bench"  # starter | bench | academy
    # Weeks at the current club (ticks weekly, resets when they move).
    # Feeds loyalty: tenured players are pricier to pry away and protected
    # from AI churn. 0 on old saves — heals as weeks tick.
    tenure_weeks: int = 0
    morale: float = Field(default=70.0, ge=0.0, le=100.0)
    stamina: float = Field(default=100.0, ge=0.0, le=100.0)
    form: float = Field(default=50.0, ge=0.0, le=100.0)

    # Confidence: belief in their own game right now. The match engine
    # reads it NEUTRAL-SAFE (exact no-op at 50 — see ADR-007), so the
    # default keeps the golden gates byte-stable; the campaign layer moves
    # it on results, personal ratings, dev events and the social layer.
    confidence: float = Field(default=50.0, ge=0.0, le=100.0)

    # Social reach. 0 = not seeded yet; manager/social.py derives a stable
    # per-player baseline (ability + id hash) on first touch.
    followers: int = 0

    # Streaming load: how much of the player's week goes to streaming vs
    # practice (0-100). Drives org stream revenue (economy.py) and a
    # current-ability growth penalty (training.py). 0 = not seeded yet;
    # manager/social.py heals it toward a follower-driven baseline each week
    # (famous players stream more), so the default keeps synthetic players
    # (no followers) penalty-free and the growth/gate math unchanged. A
    # manager's "rein it in" 1:1 (talk.py) pushes it down for more practice at
    # the cost of morale + revenue; it drifts back toward the baseline.
    stream_load: float = Field(default=0.0, ge=0.0, le=100.0)

    # Individual development plan, user-set (AI players stay on defaults).
    # dev_focus: "auto" follows the team's weekly focus, otherwise pins one
    # training category every week. "rest" opts the player out of that week's
    # training so they can recover stamina instead.
    dev_focus: str = "auto"  # auto | mechanical | tactical | mental | team | language | rest
    # The language to study when dev_focus is "language". Empty means this
    # player is not currently on a language plan.
    learning_language: str = ""
    # Intensity trades growth for stamina (and burnout risk at "intense").
    training_intensity: str = "normal"  # light | normal | intense

    # Free-form tags for personality. The narrative layer keys off these.
    personality_tags: list[str] = Field(default_factory=list)

    def attr(self, attr_id: str, default: float = 50.0) -> float:
        """Read an attribute by id with a default, never raises."""
        return self.attributes.get(attr_id, default)

    def agent_mastery(self, agent_id: str, default: float = 0.0) -> float:
        for m in self.agent_pool:
            if m.agent_id == agent_id:
                return m.mastery
        return default

    def map_mastery(self, map_id: str, default: float = 0.0) -> float:
        for mastery in self.map_pool:
            if mastery.map_id == map_id:
                return mastery.mastery
        return default


class FutureProspect(BaseModel):
    """A real player developing off-screen until their 17th birthday.

    Prospects are deliberately kept out of ``GameState.players`` until their
    debut year. They still carry the full Player profile, so the same
    deterministic age/development curve applies before and after entry.
    """

    model_config = ConfigDict(extra="forbid")

    player: Player
    debut_year: int = Field(ge=2021, le=2100)
